<template>
  <div class="fixed bottom-4 right-4 z-50">
    <!-- Chat Toggle Button -->
    <button
      v-if="!isOpen"
      @click="openChat"
      class="bg-blue-600 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 transition-colors"
    >
      <MessageCircleIcon class="h-6 w-6" />
    </button>

    <!-- Chat Window -->
    <div
      v-if="isOpen"
      class="bg-white rounded-lg shadow-xl border w-80 h-96 flex flex-col"
    >
      <!-- Chat Header -->
      <div class="bg-blue-600 text-white p-4 rounded-t-lg flex items-center justify-between">
        <div>
          <h3 class="font-semibold">Support Chat</h3>
          <p class="text-sm opacity-90">We're here to help!</p>
        </div>
        <button
          @click="closeChat"
          class="text-white hover:text-gray-200 transition-colors"
        >
          <XIcon class="h-5 w-5" />
        </button>
      </div>

      <!-- Chat Messages -->
      <div class="flex-1 overflow-y-auto p-4 space-y-3" ref="messagesContainer">
        <div
          v-for="message in messages"
          :key="message.id"
          :class="[
            'flex',
            message.isFromAdmin ? 'justify-end' : 'justify-start'
          ]"
        >
          <div
            :class="[
              'max-w-xs px-3 py-2 rounded-lg text-sm',
              message.isFromAdmin
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-900'
            ]"
          >
            <p>{{ message.message }}</p>
            <p class="text-xs opacity-70 mt-1">
              {{ formatTime(message.createdAt) }}
            </p>
          </div>
        </div>
        
        <!-- Typing Indicator -->
        <div v-if="isTyping" class="flex justify-start">
          <div class="bg-gray-100 px-3 py-2 rounded-lg text-sm">
            <div class="flex space-x-1">
              <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
              <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay: 0.1s"></div>
              <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay: 0.2s"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Chat Input -->
      <div class="p-4 border-t">
        <div class="flex space-x-2">
          <input
            v-model="newMessage"
            @keyup.enter="sendMessage"
            type="text"
            placeholder="Type your message..."
            class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            :disabled="sending"
          />
          <button
            @click="sendMessage"
            :disabled="!newMessage.trim() || sending"
            class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <SendIcon class="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, onUnmounted, nextTick } from 'vue'
import { useAuthStore } from '../stores/auth'
import { useToast } from 'vue-toastification'
import { io } from 'socket.io-client'
import {
  MessageCircleIcon,
  XIcon,
  SendIcon
} from 'lucide-vue-next'

export default {
  name: 'SupportChat',
  props: {
    orderId: {
      type: String,
      default: null
    }
  },
  setup(props) {
    const authStore = useAuthStore()
    const toast = useToast()
    
    const isOpen = ref(false)
    const messages = ref([])
    const newMessage = ref('')
    const sending = ref(false)
    const isTyping = ref(false)
    const messagesContainer = ref(null)
    const socket = ref(null)

    const openChat = () => {
      isOpen.value = true
      initializeSocket()
    }

    const closeChat = () => {
      isOpen.value = false
      if (socket.value) {
        socket.value.disconnect()
        socket.value = null
      }
    }

    const initializeSocket = () => {
      if (socket.value) return

      socket.value = io(import.meta.env.VITE_API_URL || 'http://localhost:3001')
      
      socket.value.on('connect', () => {
        console.log('Connected to support chat')
        // Join user room for order-specific support
        if (props.orderId) {
          socket.value.emit('join-user-room', authStore.user?.id)
        }
      })

      socket.value.on('support-message', (message) => {
        messages.value.push(message)
        scrollToBottom()
      })

      socket.value.on('admin-typing', () => {
        isTyping.value = true
        setTimeout(() => {
          isTyping.value = false
        }, 3000)
      })

      // Load existing messages
      loadMessages()
    }

    const loadMessages = async () => {
      try {
        // This would be replaced with actual API call
        // For now, using mock data
        messages.value = [
          {
            id: 1,
            message: 'Hello! How can I help you today?',
            isFromAdmin: true,
            createdAt: new Date().toISOString()
          }
        ]
      } catch (error) {
        console.error('Error loading messages:', error)
      }
    }

    const sendMessage = async () => {
      if (!newMessage.value.trim() || sending.value) return

      const message = {
        id: Date.now(),
        message: newMessage.value,
        isFromAdmin: false,
        createdAt: new Date().toISOString()
      }

      messages.value.push(message)
      newMessage.value = ''
      sending.value = true

      try {
        // Send message via socket
        if (socket.value) {
          socket.value.emit('support-message', {
            message: message.message,
            orderId: props.orderId,
            userId: authStore.user?.id
          })
        }
        
        scrollToBottom()
      } catch (error) {
        console.error('Error sending message:', error)
        toast.error('Failed to send message')
      } finally {
        sending.value = false
      }
    }

    const scrollToBottom = () => {
      nextTick(() => {
        if (messagesContainer.value) {
          messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
        }
      })
    }

    const formatTime = (dateString) => {
      return new Date(dateString).toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
      })
    }

    onMounted(() => {
      // Auto-open chat if there's an order context
      if (props.orderId) {
        openChat()
      }
    })

    onUnmounted(() => {
      if (socket.value) {
        socket.value.disconnect()
      }
    })

    return {
      isOpen,
      messages,
      newMessage,
      sending,
      isTyping,
      messagesContainer,
      openChat,
      closeChat,
      sendMessage,
      formatTime
    }
  }
}
</script>

