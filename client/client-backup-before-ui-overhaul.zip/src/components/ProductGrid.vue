<template>
  <div class="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
    <!-- Hero Section -->
    <section class="relative overflow-hidden bg-gradient-to-r from-blue-600 to-purple-700 text-white">
      <div class="absolute inset-0 bg-black/20"></div>
      <div class="relative container mx-auto px-4 py-20">
        <div class="max-w-4xl mx-auto text-center">
          <h1 class="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Premium Socks Collection
          </h1>
          <p class="text-xl md:text-2xl mb-8 text-blue-100 max-w-3xl mx-auto">
            Discover our carefully curated collection of athletic, casual, and dress socks. 
            Quality comfort for every occasion.
          </p>
          <div class="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              @click="scrollToProducts"
              class="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-blue-50 transition-colors shadow-lg"
            >
              Shop Now
            </button>
            <button
              @click="scrollToFeatures"
              class="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors"
            >
              Learn More
            </button>
          </div>
        </div>
      </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-20 bg-white">
      <div class="container mx-auto px-4">
        <div class="text-center mb-16">
          <h2 class="text-4xl font-bold text-gray-900 mb-4">Why Choose MatchyStore?</h2>
          <p class="text-xl text-gray-600 max-w-2xl mx-auto">
            We're committed to providing the highest quality socks with exceptional comfort and style.
          </p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div class="text-center p-6">
            <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <PackageIcon class="h-8 w-8 text-blue-600" />
            </div>
            <h3 class="text-xl font-semibold mb-2">Premium Quality</h3>
            <p class="text-gray-600">Made from the finest materials for lasting comfort and durability.</p>
          </div>
          
          <div class="text-center p-6">
            <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShoppingCartIcon class="h-8 w-8 text-green-600" />
            </div>
            <h3 class="text-xl font-semibold mb-2">Easy Shopping</h3>
            <p class="text-gray-600">Simple checkout process with secure payment and fast delivery.</p>
          </div>
          
          <div class="text-center p-6">
            <div class="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <EyeIcon class="h-8 w-8 text-purple-600" />
            </div>
            <h3 class="text-xl font-semibold mb-2">Perfect Fit</h3>
            <p class="text-gray-600">Available in all sizes with detailed sizing guides for the perfect fit.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Products Section -->
    <section id="products" class="py-20 bg-gray-50">
      <div class="container mx-auto px-4">
        <div class="text-center mb-16">
          <h2 class="text-4xl font-bold text-gray-900 mb-4">Our Products</h2>
          <p class="text-xl text-gray-600 max-w-2xl mx-auto">
            Browse our extensive collection of premium socks for every occasion.
          </p>
        </div>

    <!-- Filters -->
    <div class="mb-8 space-y-4">
      <!-- Search Bar -->
      <div class="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div class="relative flex-1 max-w-md">
          <SearchIcon class="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            v-model="searchQuery"
            @input="handleSearch"
            type="text"
            placeholder="Search products..."
            class="w-full pl-10 pr-4 py-2 border border-input rounded-md bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
          />
        </div>

        <!-- Filter Dropdowns -->
        <div class="flex gap-4">
          <select
            v-model="selectedCategory"
            @change="handleCategoryFilter"
            class="px-3 py-2 border border-input rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
          >
            <option value="">All Categories</option>
            <option v-for="category in productStore.categories" :key="category.id" :value="category.id">
              {{ category.name }}
            </option>
          </select>

          <select
            v-model="selectedBrand"
            @change="handleBrandFilter"
            class="px-3 py-2 border border-input rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
          >
            <option value="">All Brands</option>
            <option v-for="brand in productStore.brands" :key="brand.id" :value="brand.id">
              {{ brand.name }}
            </option>
          </select>

          <select
            v-model="sortBy"
            @change="handleSort"
            class="px-3 py-2 border border-input rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
          >
            <option value="createdAt">Newest First</option>
            <option value="name">Name A-Z</option>
            <option value="price">Price Low-High</option>
          </select>
        </div>
      </div>

      <!-- Active Filters -->
      <div v-if="hasActiveFilters" class="flex flex-wrap gap-2">
        <span class="text-sm text-muted-foreground">Active filters:</span>
        <button
          v-if="searchQuery"
          @click="clearSearch"
          class="inline-flex items-center gap-1 px-2 py-1 bg-primary text-primary-foreground text-xs rounded-full"
        >
          Search: "{{ searchQuery }}"
          <XIcon class="h-3 w-3" />
        </button>
        <button
          v-if="selectedCategory"
          @click="clearCategoryFilter"
          class="inline-flex items-center gap-1 px-2 py-1 bg-primary text-primary-foreground text-xs rounded-full"
        >
          Category: {{ getCategoryName(selectedCategory) }}
          <XIcon class="h-3 w-3" />
        </button>
        <button
          v-if="selectedBrand"
          @click="clearBrandFilter"
          class="inline-flex items-center gap-1 px-2 py-1 bg-primary text-primary-foreground text-xs rounded-full"
        >
          Brand: {{ getBrandName(selectedBrand) }}
          <XIcon class="h-3 w-3" />
        </button>
        <button
          @click="clearAllFilters"
          class="text-sm text-muted-foreground hover:text-foreground underline"
        >
          Clear all
        </button>
      </div>
    </div>

    <!-- Loading State -->
    <div v-if="productStore.loading" class="flex justify-center items-center py-12">
      <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
    </div>

    <!-- Products Grid -->
    <div v-else-if="productStore.products.length > 0" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      <div
        v-for="product in productStore.products"
        :key="product.id"
        class="group card-hover bg-card border border-border rounded-lg overflow-hidden"
      >
        <!-- Product Image -->
        <div class="aspect-square relative overflow-hidden bg-muted">
          <img
            :src="product.images[0] || '/placeholder-sock.jpg'"
            :alt="product.name"
            class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div class="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
          
          <!-- Quick Actions -->
          <div class="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button
              @click="productStore.openModal(product)"
              class="p-2 bg-background/80 backdrop-blur-sm rounded-full hover:bg-background transition-colors"
            >
              <EyeIcon class="h-4 w-4" />
            </button>
          </div>
        </div>

        <!-- Product Info -->
        <div class="p-4 space-y-3">
          <!-- Brand -->
          <div v-if="product.brand" class="text-xs text-muted-foreground uppercase tracking-wide">
            {{ product.brand.name }}
          </div>

          <!-- Product Name -->
          <h3 class="font-semibold text-sm line-clamp-2 group-hover:text-primary transition-colors">
            {{ product.name }}
          </h3>

          <!-- Price -->
          <div class="flex items-center justify-between">
            <span class="text-lg font-bold text-primary">
              ${{ parseFloat(product.price).toFixed(2) }}
            </span>
            <span v-if="product.stock <= 10" class="text-xs text-destructive">
              Only {{ product.stock }} left
            </span>
          </div>

          <!-- Actions -->
          <div class="flex gap-2">
            <button
              @click="addToCart(product.id)"
              :disabled="product.stock === 0"
              class="flex-1 btn-primary py-2 px-3 rounded-md text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ShoppingCartIcon class="h-4 w-4 mr-1" />
              Add to Cart
            </button>
            <button
              @click="productStore.openModal(product)"
              class="px-3 py-2 border border-input rounded-md hover:bg-muted transition-colors"
            >
              <EyeIcon class="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Empty State -->
    <div v-else class="text-center py-12">
      <div class="text-muted-foreground mb-4">
        <PackageIcon class="h-12 w-12 mx-auto mb-4" />
        <h3 class="text-lg font-semibold mb-2">No products found</h3>
        <p>Try adjusting your search or filter criteria</p>
      </div>
      <button
        @click="clearAllFilters"
        class="btn-primary px-4 py-2 rounded-md"
      >
        Clear Filters
      </button>
    </div>

    <!-- Pagination -->
    <div v-if="productStore.pagination.pages > 1" class="mt-8 flex justify-center">
      <div class="flex gap-2">
        <button
          @click="loadPage(productStore.pagination.page - 1)"
          :disabled="productStore.pagination.page <= 1"
          class="px-3 py-2 border border-input rounded-md hover:bg-muted disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Previous
        </button>
        
        <button
          v-for="page in visiblePages"
          :key="page"
          @click="loadPage(page)"
          :class="[
            'px-3 py-2 rounded-md',
            page === productStore.pagination.page
              ? 'bg-primary text-primary-foreground'
              : 'border border-input hover:bg-muted'
          ]"
        >
          {{ page }}
        </button>

        <button
          @click="loadPage(productStore.pagination.page + 1)"
          :disabled="productStore.pagination.page >= productStore.pagination.pages"
          class="px-3 py-2 border border-input rounded-md hover:bg-muted disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Next
        </button>
      </div>
    </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-16">
      <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 class="text-2xl font-bold mb-4">MatchyStore</h3>
            <p class="text-gray-400 mb-4">
              Your premium destination for quality socks. Comfort, style, and durability in every pair.
            </p>
          </div>
          <div>
            <h4 class="text-lg font-semibold mb-4">Quick Links</h4>
            <ul class="space-y-2">
              <li><a href="#" class="text-gray-400 hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Contact</a></li>
              <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Shipping Info</a></li>
              <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Returns</a></li>
            </ul>
          </div>
          <div>
            <h4 class="text-lg font-semibold mb-4">Customer Service</h4>
            <ul class="space-y-2">
              <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Help Center</a></li>
              <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Size Guide</a></li>
              <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Track Order</a></li>
              <li><a href="#" class="text-gray-400 hover:text-white transition-colors">Support</a></li>
            </ul>
          </div>
          <div>
            <h4 class="text-lg font-semibold mb-4">Connect</h4>
            <p class="text-gray-400 mb-4">Follow us for updates and new arrivals</p>
            <div class="flex space-x-4">
              <a href="#" class="text-gray-400 hover:text-white transition-colors">Facebook</a>
              <a href="#" class="text-gray-400 hover:text-white transition-colors">Instagram</a>
              <a href="#" class="text-gray-400 hover:text-white transition-colors">Twitter</a>
            </div>
          </div>
        </div>
        <div class="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 MatchyStore. All rights reserved.</p>
        </div>
      </div>
    </footer>

    <!-- Product Modal -->
    <ProductModal
      v-if="productStore.selectedProduct"
      :product="productStore.selectedProduct"
      @close="productStore.closeModal"
    />
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useProductStore } from '../stores/products'
import { useCartStore } from '../stores/cart'
import { useToast } from 'vue-toastification'
import ProductModal from './ProductModal.vue'
import { 
  SearchIcon, 
  XIcon, 
  EyeIcon, 
  ShoppingCartIcon, 
  PackageIcon 
} from 'lucide-vue-next'

const productStore = useProductStore()
const cartStore = useCartStore()
const toast = useToast()

// Local state
const searchQuery = ref('')
const selectedCategory = ref('')
const selectedBrand = ref('')
const sortBy = ref('createdAt')

// Computed
const hasActiveFilters = computed(() => 
  searchQuery.value || selectedCategory.value || selectedBrand.value
)

const visiblePages = computed(() => {
  const current = productStore.pagination.page
  const total = productStore.pagination.pages
  const pages = []
  
  for (let i = Math.max(1, current - 2); i <= Math.min(total, current + 2); i++) {
    pages.push(i)
  }
  
  return pages
})

// Methods
const handleSearch = () => {
  productStore.searchProducts(searchQuery.value)
}

const handleCategoryFilter = () => {
  productStore.filterByCategory(selectedCategory.value)
}

const handleBrandFilter = () => {
  productStore.filterByBrand(selectedBrand.value)
}

const handleSort = () => {
  productStore.sortProducts(sortBy.value)
}

const clearSearch = () => {
  searchQuery.value = ''
  productStore.searchProducts('')
}

const clearCategoryFilter = () => {
  selectedCategory.value = ''
  productStore.filterByCategory('')
}

const clearBrandFilter = () => {
  selectedBrand.value = ''
  productStore.filterByBrand('')
}

const clearAllFilters = () => {
  searchQuery.value = ''
  selectedCategory.value = ''
  selectedBrand.value = ''
  sortBy.value = 'createdAt'
  productStore.clearFilters()
  productStore.fetchProducts()
}

const loadPage = (page) => {
  productStore.fetchProducts(page)
}

const scrollToProducts = () => {
  document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })
}

const scrollToFeatures = () => {
  document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })
}

const addToCart = async (productId) => {
  const result = await cartStore.addToCart(productId, 1)
  if (result.success) {
    toast.success('Added to cart!')
  } else {
    toast.error(result.error)
  }
}

const getCategoryName = (categoryId) => {
  const category = productStore.categories.find(c => c.id === categoryId)
  return category?.name || 'Unknown'
}

const getBrandName = (brandId) => {
  const brand = productStore.brands.find(b => b.id === brandId)
  return brand?.name || 'Unknown'
}

// Lifecycle
onMounted(() => {
  productStore.initialize()
})
</script>




