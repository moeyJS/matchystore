<template>
  <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
    <div class="bg-background rounded-lg shadow-lg max-w-4xl w-full max-h-[90vh] overflow-hidden">
      <!-- Header -->
      <div class="flex items-center justify-between p-6 border-b">
        <h2 class="text-2xl font-bold">{{ product.name }}</h2>
        <button
          @click="$emit('close')"
          class="p-2 hover:bg-muted rounded-full transition-colors"
        >
          <XIcon class="h-5 w-5" />
        </button>
      </div>

      <!-- Content -->
      <div class="flex flex-col lg:flex-row max-h-[calc(90vh-120px)] overflow-hidden">
        <!-- Images -->
        <div class="lg:w-1/2 p-6">
          <div class="aspect-square relative overflow-hidden rounded-lg bg-muted">
            <img
              :src="selectedImage || product.images[0] || '/placeholder-sock.jpg'"
              :alt="product.name"
              class="w-full h-full object-cover"
            />
          </div>
          
          <!-- Image Thumbnails -->
          <div v-if="product.images.length > 1" class="flex gap-2 mt-4">
            <button
              v-for="(image, index) in product.images"
              :key="index"
              @click="selectedImage = image"
              :class="[
                'w-16 h-16 rounded-md overflow-hidden border-2 transition-colors',
                selectedImage === image || (!selectedImage && index === 0)
                  ? 'border-primary'
                  : 'border-border hover:border-muted-foreground'
              ]"
            >
              <img
                :src="image"
                :alt="`${product.name} view ${index + 1}`"
                class="w-full h-full object-cover"
              />
            </button>
          </div>
        </div>

        <!-- Product Details -->
        <div class="lg:w-1/2 p-6 space-y-6 overflow-y-auto">
          <!-- Brand -->
          <div v-if="product.brand" class="text-sm text-muted-foreground uppercase tracking-wide">
            {{ product.brand.name }}
          </div>

          <!-- Price -->
          <div class="text-3xl font-bold text-primary">
            ${{ parseFloat(product.price).toFixed(2) }}
          </div>

          <!-- Stock Status -->
          <div class="flex items-center gap-2">
            <div
              :class="[
                'w-2 h-2 rounded-full',
                product.stock > 10 ? 'bg-green-500' : product.stock > 0 ? 'bg-yellow-500' : 'bg-red-500'
              ]"
            />
            <span class="text-sm">
              {{ product.stock > 10 ? 'In Stock' : product.stock > 0 ? `Only ${product.stock} left` : 'Out of Stock' }}
            </span>
          </div>

          <!-- Description -->
          <div v-if="product.description">
            <h3 class="font-semibold mb-2">Description</h3>
            <p class="text-muted-foreground text-sm leading-relaxed">
              {{ product.description }}
            </p>
          </div>

          <!-- Attributes -->
          <div v-if="product.attributes && product.attributes.length > 0">
            <h3 class="font-semibold mb-2">Product Details</h3>
            <div class="grid grid-cols-2 gap-2">
              <div
                v-for="attr in product.attributes"
                :key="attr.id"
                class="flex justify-between text-sm"
              >
                <span class="text-muted-foreground">{{ attr.name }}:</span>
                <span class="font-medium">{{ attr.value }}</span>
              </div>
            </div>
          </div>

          <!-- Quantity and Actions -->
          <div class="space-y-4">
            <!-- Quantity Selector -->
            <div>
              <label class="block text-sm font-medium mb-2">Quantity</label>
              <div class="flex items-center gap-2">
                <button
                  @click="decreaseQuantity"
                  :disabled="quantity <= 1"
                  class="p-2 border border-input rounded-md hover:bg-muted disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <MinusIcon class="h-4 w-4" />
                </button>
                <span class="px-4 py-2 border border-input rounded-md min-w-[60px] text-center">
                  {{ quantity }}
                </span>
                <button
                  @click="increaseQuantity"
                  :disabled="quantity >= product.stock"
                  class="p-2 border border-input rounded-md hover:bg-muted disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <PlusIcon class="h-4 w-4" />
                </button>
              </div>
            </div>

            <!-- Action Buttons -->
            <div class="flex gap-3">
              <button
                @click="addToCart"
                :disabled="product.stock === 0 || loading"
                class="flex-1 btn-primary py-3 px-4 rounded-md font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <ShoppingCartIcon class="h-4 w-4" />
                <span v-if="loading">Adding...</span>
                <span v-else>Add to Cart</span>
              </button>
              <button
                @click="buyNow"
                :disabled="product.stock === 0 || loading"
                class="flex-1 bg-destructive text-destructive-foreground hover:bg-destructive/90 py-3 px-4 rounded-md font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <ZapIcon class="h-4 w-4" />
                Buy Now
              </button>
            </div>
          </div>

          <!-- Additional Info -->
          <div class="pt-4 border-t space-y-2 text-sm text-muted-foreground">
            <div class="flex items-center gap-2">
              <TruckIcon class="h-4 w-4" />
              <span>Free shipping on orders over $50</span>
            </div>
            <div class="flex items-center gap-2">
              <RefreshCwIcon class="h-4 w-4" />
              <span>30-day return policy</span>
            </div>
            <div class="flex items-center gap-2">
              <ShieldIcon class="h-4 w-4" />
              <span>Secure checkout</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { useCartStore } from '../stores/cart'
import { useToast } from 'vue-toastification'
import {
  XIcon,
  MinusIcon,
  PlusIcon,
  ShoppingCartIcon,
  ZapIcon,
  TruckIcon,
  RefreshCwIcon,
  ShieldIcon
} from 'lucide-vue-next'

const props = defineProps({
  product: {
    type: Object,
    required: true
  }
})

const emit = defineEmits(['close'])

const router = useRouter()
const cartStore = useCartStore()
const toast = useToast()

// Local state
const selectedImage = ref(null)
const quantity = ref(1)
const loading = ref(false)

// Computed
const maxQuantity = computed(() => props.product.stock)

// Methods
const increaseQuantity = () => {
  if (quantity.value < maxQuantity.value) {
    quantity.value++
  }
}

const decreaseQuantity = () => {
  if (quantity.value > 1) {
    quantity.value--
  }
}

const addToCart = async () => {
  if (props.product.stock === 0) return

  loading.value = true
  try {
    const result = await cartStore.addToCart(props.product.id, quantity.value)
    if (result.success) {
      toast.success(`Added ${quantity.value} item(s) to cart!`)
      emit('close')
    } else {
      toast.error(result.error)
    }
  } finally {
    loading.value = false
  }
}

const buyNow = async () => {
  if (props.product.stock === 0) return

  loading.value = true
  try {
    // Add to cart first
    const result = await cartStore.addToCart(props.product.id, quantity.value)
    if (result.success) {
      // Navigate to checkout
      emit('close')
      router.push('/checkout')
    } else {
      toast.error(result.error)
    }
  } finally {
    loading.value = false
  }
}
</script>





