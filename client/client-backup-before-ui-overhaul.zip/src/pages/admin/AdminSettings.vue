<template>
  <div class="min-h-screen bg-gray-50">
    <AdminLayout>
      <div class="p-6">
        <div class="mb-8">
          <h1 class="text-3xl font-bold text-gray-900">Settings</h1>
          <p class="text-gray-600 mt-2">Manage your store configuration and preferences</p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <!-- Settings Navigation -->
          <div class="lg:col-span-1">
            <nav class="space-y-1">
              <button
                v-for="tab in settingsTabs"
                :key="tab.id"
                @click="activeTab = tab.id"
                :class="[
                  'w-full text-left px-3 py-2 text-sm font-medium rounded-md transition-colors',
                  activeTab === tab.id
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                ]"
              >
                {{ tab.name }}
              </button>
            </nav>
          </div>

          <!-- Settings Content -->
          <div class="lg:col-span-2">
            <div class="bg-white rounded-lg shadow">
              <!-- General Settings -->
              <div v-if="activeTab === 'general'" class="p-6">
                <h2 class="text-lg font-semibold text-gray-900 mb-6">General Settings</h2>
                
                <form @submit.prevent="saveGeneralSettings" class="space-y-6">
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Store Name</label>
                    <input
                      v-model="settings.general.storeName"
                      type="text"
                      class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter store name"
                    >
                  </div>

                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Store Description</label>
                    <textarea
                      v-model="settings.general.storeDescription"
                      rows="3"
                      class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter store description"
                    ></textarea>
                  </div>

                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Store Email</label>
                    <input
                      v-model="settings.general.storeEmail"
                      type="email"
                      class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter store email"
                    >
                  </div>

                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Store Phone</label>
                    <input
                      v-model="settings.general.storePhone"
                      type="tel"
                      class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter store phone"
                    >
                  </div>

                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Store Address</label>
                    <textarea
                      v-model="settings.general.storeAddress"
                      rows="3"
                      class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter store address"
                    ></textarea>
                  </div>

                  <div class="flex justify-end">
                    <button
                      type="submit"
                      class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      Save Changes
                    </button>
                  </div>
                </form>
              </div>

              <!-- Notifications Settings -->
              <div v-if="activeTab === 'notifications'" class="p-6">
                <h2 class="text-lg font-semibold text-gray-900 mb-6">Notification Settings</h2>
                
                <div class="space-y-6">
                  <div class="flex items-center justify-between">
                    <div>
                      <h3 class="text-sm font-medium text-gray-900">Email Notifications</h3>
                      <p class="text-sm text-gray-500">Receive email notifications for new orders</p>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                      <input
                        v-model="settings.notifications.emailOrders"
                        type="checkbox"
                        class="sr-only peer"
                      >
                      <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>

                  <div class="flex items-center justify-between">
                    <div>
                      <h3 class="text-sm font-medium text-gray-900">Low Stock Alerts</h3>
                      <p class="text-sm text-gray-500">Get notified when products are running low</p>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                      <input
                        v-model="settings.notifications.lowStock"
                        type="checkbox"
                        class="sr-only peer"
                      >
                      <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>

                  <div class="flex items-center justify-between">
                    <div>
                      <h3 class="text-sm font-medium text-gray-900">Customer Support</h3>
                      <p class="text-sm text-gray-500">Receive notifications for new support tickets</p>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                      <input
                        v-model="settings.notifications.supportTickets"
                        type="checkbox"
                        class="sr-only peer"
                      >
                      <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>

                  <div class="flex justify-end">
                    <button
                      @click="saveNotificationSettings"
                      class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      Save Changes
                    </button>
                  </div>
                </div>
              </div>

              <!-- Integrations Settings -->
              <div v-if="activeTab === 'integrations'" class="p-6">
                <h2 class="text-lg font-semibold text-gray-900 mb-6">Integrations</h2>
                
                <div class="space-y-6">
                  <div class="border border-gray-200 rounded-lg p-4">
                    <div class="flex items-center justify-between">
                      <div>
                        <h3 class="text-sm font-medium text-gray-900">Payment Gateway</h3>
                        <p class="text-sm text-gray-500">Configure payment processing</p>
                      </div>
                      <button class="text-blue-600 hover:text-blue-700 text-sm font-medium">
                        Configure
                      </button>
                    </div>
                  </div>

                  <div class="border border-gray-200 rounded-lg p-4">
                    <div class="flex items-center justify-between">
                      <div>
                        <h3 class="text-sm font-medium text-gray-900">Shipping Provider</h3>
                        <p class="text-sm text-gray-500">Set up shipping integrations</p>
                      </div>
                      <button class="text-blue-600 hover:text-blue-700 text-sm font-medium">
                        Configure
                      </button>
                    </div>
                  </div>

                  <div class="border border-gray-200 rounded-lg p-4">
                    <div class="flex items-center justify-between">
                      <div>
                        <h3 class="text-sm font-medium text-gray-900">Email Service</h3>
                        <p class="text-sm text-gray-500">Configure email delivery</p>
                      </div>
                      <button class="text-blue-600 hover:text-blue-700 text-sm font-medium">
                        Configure
                      </button>
                    </div>
                  </div>

                  <div class="border border-gray-200 rounded-lg p-4">
                    <div class="flex items-center justify-between">
                      <div>
                        <h3 class="text-sm font-medium text-gray-900">Analytics</h3>
                        <p class="text-sm text-gray-500">Connect Google Analytics</p>
                      </div>
                      <button class="text-blue-600 hover:text-blue-700 text-sm font-medium">
                        Configure
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <!-- System Settings -->
              <div v-if="activeTab === 'system'" class="p-6">
                <h2 class="text-lg font-semibold text-gray-900 mb-6">System Settings</h2>
                <div class="space-y-6">
                  <div class="flex items-center justify-between">
                    <div>
                      <h3 class="text-sm font-medium text-gray-900">Maintenance Mode</h3>
                      <p class="text-sm text-gray-500">Put the site into maintenance mode</p>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                      <input v-model="settings.system.maintenanceMode" type="checkbox" class="sr-only peer">
                      <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                  <div class="flex items-center justify-between">
                    <div>
                      <h3 class="text-sm font-medium text-gray-900">Cache Enabled</h3>
                      <p class="text-sm text-gray-500">Enable response caching</p>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                      <input v-model="settings.system.cacheEnabled" type="checkbox" class="sr-only peer">
                      <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                  <div class="flex justify-end">
                    <button @click="saveSystemSettings" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Save Changes</button>
                  </div>
                </div>
              </div>

              <!-- SMTP Settings -->
              <div v-if="activeTab === 'smtp'" class="p-6">
                <h2 class="text-lg font-semibold text-gray-900 mb-6">SMTP Settings</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Host</label>
                    <input v-model="settings.smtp.host" type="text" class="w-full border border-gray-300 rounded-md px-3 py-2" placeholder="smtp.mailprovider.com">
                  </div>
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Port</label>
                    <input v-model.number="settings.smtp.port" type="number" class="w-full border border-gray-300 rounded-md px-3 py-2" placeholder="587">
                  </div>
                  <div class="flex items-center space-x-2">
                    <input v-model="settings.smtp.secure" id="smtp-secure" type="checkbox" class="rounded border-gray-300">
                    <label for="smtp-secure" class="text-sm text-gray-700">Use TLS/SSL</label>
                  </div>
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">User</label>
                    <input v-model="settings.smtp.user" type="text" class="w-full border border-gray-300 rounded-md px-3 py-2" placeholder="username">
                  </div>
                  <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">From Email</label>
                    <input v-model="settings.smtp.fromEmail" type="email" class="w-full border border-gray-300 rounded-md px-3 py-2" placeholder="no-reply@yourstore.com">
                  </div>
                </div>
                <div class="flex items-center justify-between mt-6">
                  <button @click="saveSmtpSettings" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Save SMTP</button>
                  <div class="flex items-center space-x-2">
                    <input v-model="smtpTestEmail" type="email" class="border border-gray-300 rounded-md px-3 py-2" placeholder="test@yourdomain.com">
                    <button @click="testSmtp" class="border border-gray-300 px-4 py-2 rounded hover:bg-gray-50">Send Test</button>
                  </div>
                </div>
              </div>

              <!-- OTP Settings -->
              <div v-if="activeTab === 'otp'" class="p-6">
                <h2 class="text-lg font-semibold text-gray-900 mb-6">OTP Provider</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Provider</label>
                    <select v-model="settings.otp.provider" class="w-full border border-gray-300 rounded-md px-3 py-2">
                      <option value="mock">Mock</option>
                      <option value="twilio">Twilio</option>
                      <option value="vonage">Vonage</option>
                    </select>
                  </div>
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Sender ID</label>
                    <input v-model="settings.otp.senderId" type="text" class="w-full border border-gray-300 rounded-md px-3 py-2">
                  </div>
                  <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">API Key (stored securely)</label>
                    <input v-model="settings.otp.apiKey" type="password" class="w-full border border-gray-300 rounded-md px-3 py-2">
                  </div>
                </div>
                <div class="flex justify-end mt-6">
                  <button @click="saveOtpSettings" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Save OTP</button>
                </div>
              </div>

              <!-- Analytics Settings -->
              <div v-if="activeTab === 'analytics'" class="p-6">
                <h2 class="text-lg font-semibold text-gray-900 mb-6">Analytics</h2>
                <div>
                  <label class="block text-sm font-medium text-gray-700 mb-2">GA Measurement ID</label>
                  <input v-model="settings.analytics.gaMeasurementId" type="text" class="w-full border border-gray-300 rounded-md px-3 py-2" placeholder="G-XXXXXXXXXX">
                </div>
                <div class="flex justify-end mt-6">
                  <button @click="saveAnalyticsSettings" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Save Analytics</button>
                </div>
              </div>

              <!-- Payments Settings -->
              <div v-if="activeTab === 'payments'" class="p-6 space-y-6">
                <h2 class="text-lg font-semibold text-gray-900">Payments</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div class="border rounded-lg p-4">
                    <h3 class="font-medium mb-3">ZainCash</h3>
                    <label class="inline-flex items-center space-x-2 mb-3">
                      <input type="checkbox" v-model="settings.payments.zaincash.enabled"/>
                      <span>Enable</span>
                    </label>
                    <input v-model="settings.payments.zaincash.merchantId" class="w-full border rounded px-3 py-2 mb-2" placeholder="Merchant ID"/>
                    <input v-model="settings.payments.zaincash.secret" type="password" class="w-full border rounded px-3 py-2 mb-2" placeholder="Secret"/>
                    <label class="inline-flex items-center space-x-2"><input type="checkbox" v-model="settings.payments.zaincash.production"/><span>Production</span></label>
                  </div>
                  <div class="border rounded-lg p-4">
                    <h3 class="font-medium mb-3">FastPay</h3>
                    <label class="inline-flex items-center space-x-2 mb-3">
                      <input type="checkbox" v-model="settings.payments.fastpay.enabled"/>
                      <span>Enable</span>
                    </label>
                    <input v-model="settings.payments.fastpay.clientId" class="w-full border rounded px-3 py-2 mb-2" placeholder="Client ID"/>
                    <input v-model="settings.payments.fastpay.secret" type="password" class="w-full border rounded px-3 py-2 mb-2" placeholder="Secret"/>
                    <label class="inline-flex items-center space-x-2"><input type="checkbox" v-model="settings.payments.fastpay.production"/><span>Production</span></label>
                  </div>
                  <div class="border rounded-lg p-4">
                    <h3 class="font-medium mb-3">QiCard</h3>
                    <label class="inline-flex items-center space-x-2 mb-3">
                      <input type="checkbox" v-model="settings.payments.qicard.enabled"/>
                      <span>Enable</span>
                    </label>
                    <input v-model="settings.payments.qicard.terminalId" class="w-full border rounded px-3 py-2 mb-2" placeholder="Terminal ID"/>
                    <input v-model="settings.payments.qicard.secret" type="password" class="w-full border rounded px-3 py-2 mb-2" placeholder="Secret"/>
                    <label class="inline-flex items-center space-x-2"><input type="checkbox" v-model="settings.payments.qicard.production"/><span>Production</span></label>
                  </div>
                </div>
                <div class="flex justify-end">
                  <button @click="savePaymentsSettings" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Save Payments</button>
                </div>
              </div>

              <!-- Localization Settings -->
              <div v-if="activeTab === 'localization'" class="p-6 space-y-6">
                <h2 class="text-lg font-semibold text-gray-900">Localization</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Default Locale</label>
                    <select v-model="settings.localization.defaultLocale" class="w-full border rounded px-3 py-2">
                      <option value="en">English</option>
                      <option value="ar">Arabic</option>
                    </select>
                  </div>
                  <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Currency</label>
                    <select v-model="settings.localization.currency" class="w-full border rounded px-3 py-2">
                      <option value="USD">USD</option>
                      <option value="EUR">EUR</option>
                      <option value="IQD">IQD</option>
                    </select>
                  </div>
                  <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Supported Locales</label>
                    <input v-model="supportedLocalesInput" class="w-full border rounded px-3 py-2" placeholder="en,ar"/>
                  </div>
                </div>
                <div class="flex justify-end">
                  <button @click="saveLocalizationSettings" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Save Localization</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import AdminLayout from '../../components/AdminLayout.vue'

export default {
  name: 'AdminSettings',
  components: {
    AdminLayout
  },
  setup() {
    const activeTab = ref('general')
    
    const settingsTabs = [
      { id: 'general', name: 'General' },
      { id: 'notifications', name: 'Notifications' },
      { id: 'integrations', name: 'Integrations' },
      { id: 'system', name: 'System' },
      { id: 'smtp', name: 'SMTP' },
      { id: 'otp', name: 'OTP' },
      { id: 'analytics', name: 'Analytics' },
      { id: 'payments', name: 'Payments' },
      { id: 'localization', name: 'Localization' }
    ]

    const settings = ref({
      general: {
        storeName: '',
        storeDescription: '',
        storeEmail: '',
        storePhone: '',
        storeAddress: ''
      },
      notifications: {
        emailOrders: true,
        lowStock: true,
        supportTickets: true
      },
      system: { maintenanceMode: false, cacheEnabled: true },
      smtp: { host: '', port: 587, secure: false, user: '', fromEmail: '' },
      otp: { provider: 'mock', senderId: '', apiKey: '' },
      analytics: { gaMeasurementId: '' },
      payments: {
        zaincash: { enabled: false, merchantId: '', secret: '', production: false },
        fastpay: { enabled: false, clientId: '', secret: '', production: false },
        qicard: { enabled: false, terminalId: '', secret: '', production: false }
      },
      localization: { defaultLocale: 'en', supportedLocales: ['en'], currency: 'USD', currencyFormat: 'en-US' }
    })

    const saveGeneralSettings = async () => {
      try {
        await axios.put('/api/admin/settings/general', {
          storeName: settings.value.general.storeName,
          storeEmail: settings.value.general.storeEmail,
          phone: settings.value.general.storePhone,
          address: settings.value.general.storeAddress
        })
      } catch (error) {
        console.error('Error saving general settings:', error)
      }
    }

    const saveNotificationSettings = async () => {
      try {
        await axios.put('/api/admin/settings/notifications', {
          orderNotifications: settings.value.notifications.emailOrders,
          lowStockAlerts: settings.value.notifications.lowStock,
          systemUpdates: settings.value.notifications.supportTickets
        })
      } catch (error) {
        console.error('Error saving notification settings:', error)
      }
    }

    const saveSystemSettings = async () => {
      try {
        await axios.put('/api/admin/settings/system', settings.value.system)
      } catch (error) {
        console.error('Error saving system settings:', error)
      }
    }

    const saveSmtpSettings = async () => {
      try {
        await axios.put('/api/admin/settings/smtp', settings.value.smtp)
      } catch (error) {
        console.error('Error saving SMTP settings:', error)
      }
    }

    const smtpTestEmail = ref('')
    const testSmtp = async () => {
      try {
        await axios.post('/api/admin/settings/smtp/test', { to: smtpTestEmail.value })
      } catch (error) {
        console.error('Error sending test email:', error)
      }
    }

    const saveOtpSettings = async () => {
      try {
        await axios.put('/api/admin/settings/otp', settings.value.otp)
      } catch (error) {
        console.error('Error saving OTP settings:', error)
      }
    }

    const saveAnalyticsSettings = async () => {
      try {
        await axios.put('/api/admin/settings/analytics', settings.value.analytics)
      } catch (error) {
        console.error('Error saving analytics settings:', error)
      }
    }

    const savePaymentsSettings = async () => {
      try {
        await axios.put('/api/admin/settings/payments', settings.value.payments)
      } catch (error) {
        console.error('Error saving payments settings:', error)
      }
    }

    const supportedLocalesInput = ref('en')
    const saveLocalizationSettings = async () => {
      try {
        const locales = supportedLocalesInput.value.split(',').map(s => s.trim()).filter(Boolean)
        await axios.put('/api/admin/settings/localization', {
          ...settings.value.localization,
          supportedLocales: locales
        })
      } catch (error) {
        console.error('Error saving localization settings:', error)
      }
    }

    const fetchSettings = async () => {
      try {
        const [gen, notif, sys, smtp, otp, analytics, payments, localization] = await Promise.all([
          axios.get('/api/admin/settings/general'),
          axios.get('/api/admin/settings/notifications'),
          axios.get('/api/admin/settings/system'),
          axios.get('/api/admin/settings/smtp'),
          axios.get('/api/admin/settings/otp'),
          axios.get('/api/admin/settings/analytics'),
          axios.get('/api/admin/settings/payments'),
          axios.get('/api/admin/settings/localization')
        ])
        settings.value.general = {
          storeName: gen.data.storeName,
          storeDescription: settings.value.general.storeDescription,
          storeEmail: gen.data.storeEmail,
          storePhone: gen.data.phone,
          storeAddress: gen.data.address
        }
        settings.value.notifications = {
          emailOrders: notif.data.orderNotifications,
          lowStock: notif.data.lowStockAlerts,
          supportTickets: notif.data.systemUpdates
        }
        settings.value.system = sys.data
        settings.value.smtp = smtp.data
        settings.value.otp = { ...settings.value.otp, ...otp.data }
        settings.value.analytics = analytics.data
        settings.value.payments = payments.data
        settings.value.localization = localization.data
      } catch (error) {
        console.error('Error fetching settings:', error)
      }
    }

    onMounted(() => {
      fetchSettings()
    })

    return {
      activeTab,
      settingsTabs,
      settings,
      saveGeneralSettings,
      saveNotificationSettings,
      saveSystemSettings,
      saveSmtpSettings,
      smtpTestEmail,
      testSmtp,
      saveOtpSettings,
      saveAnalyticsSettings,
      savePaymentsSettings,
      supportedLocalesInput,
      saveLocalizationSettings
    }
  }
}
</script>

