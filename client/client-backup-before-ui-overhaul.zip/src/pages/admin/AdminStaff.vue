<template>
  <div class="min-h-screen bg-gray-50">
    <AdminLayout>
      <div class="p-6 space-y-6">
        <div class="flex items-center justify-between">
          <h1 class="text-3xl font-bold">Staff</h1>
          <button @click="openInvite" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Invite Staff</button>
        </div>

        <div class="bg-white rounded-lg shadow overflow-hidden">
          <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
              <thead class="bg-gray-50">
                <tr>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                  <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody class="bg-white divide-y divide-gray-200">
                <tr v-for="u in staff" :key="u.id" class="hover:bg-gray-50">
                  <td class="px-6 py-4 whitespace-nowrap">{{ u.name || '—' }}</td>
                  <td class="px-6 py-4 whitespace-nowrap">{{ u.email }}</td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <select v-model="u.role" @change="updateRole(u)" class="border rounded px-2 py-1 text-sm">
                      <option value="CUSTOMER_SERVICE">Customer Service</option>
                      <option value="WAREHOUSE">Warehouse</option>
                      <option value="MARKETING">Marketing</option>
                      <option value="ADMIN">Admin</option>
                      <option value="SUPER_ADMIN">Super Admin</option>
                    </select>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-right text-sm">
                    <span class="text-gray-500">Joined {{ new Date(u.createdAt).toLocaleDateString() }}</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Invite Modal -->
        <div v-if="showInvite" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div class="bg-white rounded-lg shadow w-full max-w-md p-6">
            <div class="flex items-center justify-between mb-4">
              <h3 class="text-lg font-semibold">Invite Staff</h3>
              <button @click="closeInvite" class="text-gray-600 hover:text-gray-900">Close</button>
            </div>
            <div class="space-y-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input v-model="invite.name" class="w-full border rounded px-3 py-2" placeholder="Optional"/>
              </div>
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input v-model="invite.email" class="w-full border rounded px-3 py-2" placeholder="email@domain.com"/>
              </div>
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Role</label>
                <select v-model="invite.role" class="w-full border rounded px-3 py-2">
                  <option value="CUSTOMER_SERVICE">Customer Service</option>
                  <option value="WAREHOUSE">Warehouse</option>
                  <option value="MARKETING">Marketing</option>
                  <option value="ADMIN">Admin</option>
                  <option value="SUPER_ADMIN">Super Admin</option>
                </select>
              </div>
              <div class="flex justify-end space-x-2">
                <button @click="closeInvite" class="border px-4 py-2 rounded">Cancel</button>
                <button @click="sendInvite" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Send Invite</button>
              </div>
              <div v-if="inviteResult" class="text-sm text-gray-600">Temp password: <span class="font-mono">{{ inviteResult }}</span></div>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import AdminLayout from '../../components/AdminLayout.vue'

export default {
  name: 'AdminStaff',
  components: { AdminLayout },
  setup() {
    const staff = ref([])
    const showInvite = ref(false)
    const invite = ref({ name: '', email: '', role: 'CUSTOMER_SERVICE' })
    const inviteResult = ref('')

    const load = async () => {
      const res = await axios.get('/api/admin/staff')
      staff.value = res.data.staff || []
    }

    const updateRole = async (u) => {
      await axios.put(`/api/admin/staff/${u.id}/role`, { role: u.role })
    }

    const openInvite = () => { showInvite.value = true; inviteResult.value = '' }
    const closeInvite = () => { showInvite.value = false }
    const sendInvite = async () => {
      const res = await axios.post('/api/admin/staff/invite', invite.value)
      inviteResult.value = res.data.tempPassword
      await load()
    }

    onMounted(load)
    return { staff, showInvite, invite, inviteResult, openInvite, closeInvite, sendInvite, updateRole }
  }
}
</script>


