<template>
  <div class="min-h-screen bg-gray-50">
    <AdminLayout>
      <div class="p-6 space-y-6">
        <div>
          <h1 class="text-3xl font-bold">Appearance</h1>
          <p class="text-gray-600 mt-2">Customize theme colors and branding</p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <!-- Theme Colors -->
          <div class="bg-white rounded-lg shadow p-6 space-y-4">
            <h2 class="text-lg font-semibold">Theme Colors</h2>
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Primary Color</label>
              <input type="color" v-model="form.primaryColor" class="h-10 w-20 border rounded" />
            </div>
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">Secondary Color</label>
              <input type="color" v-model="form.secondaryColor" class="h-10 w-20 border rounded" />
            </div>
            <div>
              <button @click="saveColors" :disabled="saving" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50">Save Colors</button>
            </div>
          </div>

          <!-- Logo -->
          <div class="bg-white rounded-lg shadow p-6 space-y-4">
            <h2 class="text-lg font-semibold">Brand Logo</h2>
            <div v-if="form.logo" class="flex items-center space-x-4">
              <img :src="form.logo" alt="Logo" class="h-16" />
              <button @click="removeLogo" class="text-red-600 hover:text-red-800">Remove</button>
            </div>
            <div class="space-y-2">
              <label class="block text-sm font-medium text-gray-700 mb-1">Logo URL</label>
              <input v-model="logoUrl" type="url" placeholder="https://..." class="w-full border rounded px-3 py-2" />
              <div class="flex space-x-2">
                <button @click="applyLogoUrl" class="border px-3 py-2 rounded hover:bg-gray-50">Apply</button>
                <button @click="saveLogo" :disabled="saving" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50">Save Logo</button>
              </div>
            </div>
          </div>
        </div>

        <!-- Preview -->
        <div class="bg-white rounded-lg shadow p-6">
          <h2 class="text-lg font-semibold mb-4">Preview</h2>
          <div class="p-6 rounded-lg border" :style="{ borderColor: form.secondaryColor }">
            <button class="text-white px-4 py-2 rounded" :style="{ backgroundColor: form.primaryColor }">Primary Button</button>
          </div>
        </div>
      </div>
    </AdminLayout>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import AdminLayout from '../../components/AdminLayout.vue'

export default {
  name: 'AdminAppearance',
  components: { AdminLayout },
  setup() {
    const form = ref({ primaryColor: '#3b82f6', secondaryColor: '#1e40af', logo: null })
    const logoUrl = ref('')
    const saving = ref(false)

    const load = async () => {
      const res = await axios.get('/api/admin/settings/appearance')
      form.value = res.data
    }

    const saveColors = async () => {
      saving.value = true
      try {
        await axios.put('/api/admin/settings/appearance', {
          primaryColor: form.value.primaryColor,
          secondaryColor: form.value.secondaryColor
        })
      } finally {
        saving.value = false
      }
    }

    const applyLogoUrl = () => {
      if (logoUrl.value) form.value.logo = logoUrl.value
    }

    const saveLogo = async () => {
      if (!form.value.logo) return
      saving.value = true
      try {
        await axios.put('/api/admin/settings/appearance', { logo: form.value.logo })
      } finally {
        saving.value = false
      }
    }

    const removeLogo = async () => {
      form.value.logo = null
      await axios.put('/api/admin/settings/appearance', { logo: null })
    }

    onMounted(load)

    return { form, logoUrl, saving, load, saveColors, applyLogoUrl, saveLogo, removeLogo }
  }
}
</script>



