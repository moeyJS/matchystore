<template>
  <div id="app">
    <nav class="bg-white shadow-lg">
      <div class="max-w-7xl mx-auto px-4">
        <div class="flex justify-between h-16">
          <div class="flex items-center">
            <router-link to="/" class="flex-shrink-0 flex items-center">
              <h1 class="text-2xl font-bold text-gray-900">MatchyStore</h1>
            </router-link>
          </div>
          <div class="flex items-center space-x-4">
            <router-link 
              to="/" 
              class="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium"
              :class="{ 'bg-gray-100': $route.name === 'home' }"
            >
              Products
            </router-link>
            <router-link 
              to="/cart" 
              class="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium"
              :class="{ 'bg-gray-100': $route.name === 'cart' }"
            >
              Cart ({{ cartItemCount }})
            </router-link>
            <router-link 
              :to="isAuthenticated ? '/orders' : '/track-orders'" 
              class="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium"
              :class="{ 'bg-gray-100': $route.name === 'orders' || $route.name === 'guest-orders' }"
            >
              {{ isAuthenticated ? 'Orders' : 'Track Orders' }}
            </router-link>
            <router-link 
              to="/admin" 
              class="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium"
              :class="{ 'bg-gray-100': $route.name?.startsWith('admin') }"
            >
              Admin
            </router-link>
            <div class="flex items-center space-x-2">
              <template v-if="isAuthenticated">
                <span class="text-sm text-gray-600">Welcome, {{ user?.name || 'User' }}</span>
                <button 
                  @click="logout"
                  class="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-md text-sm font-medium"
                >
                  Logout
                </button>
              </template>
              <template v-else>
                <router-link 
                  to="/login" 
                  class="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium"
                >
                  Login
                </router-link>
                <router-link 
                  to="/register" 
                  class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-md text-sm font-medium"
                >
                  Register
                </router-link>
              </template>
            </div>
          </div>
        </div>
      </div>
    </nav>

    <main class="min-h-screen bg-gray-50">
      <router-view />
    </main>

    <footer class="bg-gray-800 text-white py-8">
      <div class="max-w-7xl mx-auto px-4 text-center">
        <p>&copy; 2024 MatchyStore. All rights reserved.</p>
      </div>
    </footer>
  </div>
</template>

<script>
import { computed } from 'vue'
import { useAuthStore } from './stores/auth'
import { useCartStore } from './stores/cart'

export default {
  name: 'App',
  setup() {
    const authStore = useAuthStore()
    const cartStore = useCartStore()

    const isAuthenticated = computed(() => authStore.isAuthenticated)
    const user = computed(() => authStore.user)
    const cartItemCount = computed(() => cartStore.itemCount)

    const logout = () => {
      authStore.logout()
    }

    return {
      isAuthenticated,
      user,
      cartItemCount,
      logout
    }
  }
}
</script>
