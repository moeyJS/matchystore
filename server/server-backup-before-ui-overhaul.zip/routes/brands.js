const express = require('express');
const { PrismaClient } = require('@prisma/client');
const router = express.Router();
const prisma = new PrismaClient();

// Get all brands
router.get('/', async (req, res) => {
  try {
    const brands = await prisma.brand.findMany({
      include: {
        products: {
          select: {
            id: true,
            name: true,
            price: true,
            image: true,
            stock: true
          }
        }
      },
      orderBy: {
        name: 'asc'
      }
    });
    
    res.json(brands);
  } catch (error) {
    console.error('Error fetching brands:', error);
    res.status(500).json({ error: 'Failed to fetch brands' });
  }
});

// Get single brand
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const brand = await prisma.brand.findUnique({
      where: { id: parseInt(id) },
      include: {
        products: {
          select: {
            id: true,
            name: true,
            price: true,
            image: true,
            stock: true,
            description: true
          }
        }
      }
    });

    if (!brand) {
      return res.status(404).json({ error: 'Brand not found' });
    }

    res.json(brand);
  } catch (error) {
    console.error('Error fetching brand:', error);
    res.status(500).json({ error: 'Failed to fetch brand' });
  }
});

// Create new brand
router.post('/', async (req, res) => {
  try {
    const { name, description, logo, website, country } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Brand name is required' });
    }

    const brand = await prisma.brand.create({
      data: {
        name,
        description,
        logo,
        website,
        country
      }
    });

    res.status(201).json(brand);
  } catch (error) {
    console.error('Error creating brand:', error);
    res.status(500).json({ error: 'Failed to create brand' });
  }
});

// Update brand
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, logo, website, country } = req.body;

    const brand = await prisma.brand.update({
      where: { id: parseInt(id) },
      data: {
        name,
        description,
        logo,
        website,
        country
      }
    });

    res.json(brand);
  } catch (error) {
    console.error('Error updating brand:', error);
    res.status(500).json({ error: 'Failed to update brand' });
  }
});

// Delete brand
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Check if brand has products
    const productsCount = await prisma.product.count({
      where: { brandId: parseInt(id) }
    });

    if (productsCount > 0) {
      return res.status(400).json({ 
        error: 'Cannot delete brand with products. Please move or delete products first.' 
      });
    }

    await prisma.brand.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: 'Brand deleted successfully' });
  } catch (error) {
    console.error('Error deleting brand:', error);
    res.status(500).json({ error: 'Failed to delete brand' });
  }
});

// Get brand statistics
router.get('/:id/stats', async (req, res) => {
  try {
    const { id } = req.params;
    
    const brand = await prisma.brand.findUnique({
      where: { id: parseInt(id) },
      include: {
        products: {
          select: {
            id: true,
            price: true,
            stock: true,
            orders: {
              select: {
                quantity: true
              }
            }
          }
        }
      }
    });

    if (!brand) {
      return res.status(404).json({ error: 'Brand not found' });
    }

    const stats = {
      totalProducts: brand.products.length,
      totalStock: brand.products.reduce((sum, product) => sum + product.stock, 0),
      totalOrders: brand.products.reduce((sum, product) => 
        sum + product.orders.reduce((orderSum, order) => orderSum + order.quantity, 0), 0
      ),
      averagePrice: brand.products.length > 0 
        ? brand.products.reduce((sum, product) => sum + product.price, 0) / brand.products.length 
        : 0
    };

    res.json(stats);
  } catch (error) {
    console.error('Error fetching brand stats:', error);
    res.status(500).json({ error: 'Failed to fetch brand statistics' });
  }
});

module.exports = router;


