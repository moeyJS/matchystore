const express = require('express')
const { body, param } = require('express-validator')
const { PrismaClient } = require('@prisma/client')
const { authenticateToken, requireAdmin } = require('../middleware/auth')

const router = express.Router()
const prisma = new PrismaClient()

// List staff
router.get('/', authenticateToken, requireAdmin, async (req, res) => {
  const staff = await prisma.user.findMany({
    where: { role: { in: ['CUSTOMER_SERVICE','WAREHOUSE','MARKETING','ADMIN','SUPER_ADMIN'] } },
    select: { id: true, email: true, name: true, role: true, createdAt: true }
  })
  res.json({ staff })
})

// Update role
router.put('/:id/role', [authenticateToken, requireAdmin, param('id').notEmpty(), body('role').isString()], async (req, res) => {
  const { id } = req.params
  const { role } = req.body
  const user = await prisma.user.update({ where: { id }, data: { role } })
  res.json({ user })
})

// Invite staff (mock - creates a user with temp password)
router.post('/invite', [authenticateToken, requireAdmin, body('email').isEmail(), body('role').isString()], async (req, res) => {
  const { email, role, name } = req.body
  const tempPassword = Math.random().toString(36).slice(2, 10)
  try {
    const user = await prisma.user.create({ data: { email, role, name: name || null, password: tempPassword } })
    res.status(201).json({ user, tempPassword })
  } catch (e) {
    res.status(400).json({ error: 'Failed to invite staff' })
  }
})

module.exports = router


